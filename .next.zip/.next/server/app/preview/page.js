(()=>{var e={};e.id=517,e.ids=[517],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},6244:(e,t,r)=>{Promise.resolve().then(r.bind(r,65234))},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},16189:(e,t,r)=>{"use strict";var a=r(65773);r.o(a,"useRouter")&&r.d(t,{useRouter:function(){return a.useRouter}})},16324:()=>{},17044:(e,t,r)=>{Promise.resolve().then(r.t.bind(r,16444,23)),Promise.resolve().then(r.t.bind(r,16042,23)),Promise.resolve().then(r.t.bind(r,88170,23)),Promise.resolve().then(r.t.bind(r,49477,23)),Promise.resolve().then(r.t.bind(r,29345,23)),Promise.resolve().then(r.t.bind(r,12089,23)),Promise.resolve().then(r.t.bind(r,46577,23)),Promise.resolve().then(r.t.bind(r,31307,23))},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},29116:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>n});var a=r(60687),s=r(43210),i=r(16189);let o=[{value:"none",label:"No grouping"},{value:"date",label:"Date"},{value:"user",label:"User"},{value:"client",label:"Client"},{value:"project",label:"Project"},{value:"task",label:"Task"}];function n(){let[e,t]=(0,s.useState)(null),[r,n]=(0,s.useState)(""),[l,d]=(0,s.useState)(!1),[p,c]=(0,s.useState)("date"),[u,m]=(0,s.useState)("none"),[h,x]=(0,s.useState)("none"),g=(0,i.useRouter)(),b=(e,t,r,a)=>{let s=[];return"none"!==t&&s.push(f(e,t)),"none"!==r&&s.push(f(e,r)),"none"!==a&&s.push(f(e,a)),s.join(" → ")},f=(e,t)=>{switch(t){case"date":return e.date;case"user":return e.user;case"client":return e.client;case"project":return e.project;case"task":return e.task||"No Task";default:return""}},v=async(e,t,r,a)=>{d(!0);try{let s=new Map;e.entries.forEach(e=>{let i=b(e,t,r,a);s.has(i)||s.set(i,[]),s.get(i).push(e)});let i=y(e,s,t,r,a);n(i)}catch(e){console.error("Error generating preview:",e)}finally{d(!1)}},y=(e,t,r,a,s)=>{let i=e.entries.reduce((e,t)=>e+parseFloat(t.duration||"0"),0),o=e.entries.length,n=[...new Set(e.entries.map(e=>e.user))],l=[...new Set(e.entries.map(e=>e.project))],d=[r,a,s].filter(e=>"none"!==e),p=d.length>0?`Grouped by: ${d.map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(" → ")}`:"No grouping applied",c=Array.from(t.entries()).slice(0,3);return`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f8fafc;
            color: #1e293b;
            line-height: 1.6;
          }
          .container {
            max-width: 210mm;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
          }
          .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 3px solid #3b82f6;
          }
          .client-name {
            font-size: 28px;
            font-weight: bold;
            color: #1e40af;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
          }
          .report-title {
            font-size: 20px;
            color: #64748b;
            margin-bottom: 5px;
          }
          .grouping-info {
            font-size: 14px;
            color: #6b7280;
            font-style: italic;
            margin-top: 10px;
          }
          .summary-section {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
          }
          .summary-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
          }
          .summary-card h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            opacity: 0.9;
          }
          .summary-card .value {
            font-size: 24px;
            font-weight: bold;
            margin: 0;
          }
          .details-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
          }
          .detail-card {
            background: #f8fafc;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #3b82f6;
          }
          .detail-card h3 {
            margin: 0 0 15px 0;
            color: #1e40af;
            font-size: 16px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          .detail-list {
            list-style: none;
            padding: 0;
            margin: 0;
          }
          .detail-list li {
            padding: 5px 0;
            border-bottom: 1px solid #e2e8f0;
            color: #475569;
          }
          .detail-list li:last-child {
            border-bottom: none;
          }
          .entries-section {
            margin-top: 30px;
          }
          .group-header {
            background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
            color: white;
            padding: 15px 20px;
            margin: 20px 0 0 0;
            border-radius: 8px 8px 0 0;
            font-weight: bold;
            font-size: 16px;
            display: flex;
            justify-content: space-between;
            align-items: center;
          }
          .group-stats {
            font-size: 14px;
            opacity: 0.9;
          }
          .entries-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background: white;
            border-radius: 0 0 8px 8px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          }
          .entries-table th {
            background: #f1f5f9;
            padding: 12px 8px;
            text-align: left;
            font-weight: 600;
            color: #334155;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            border-bottom: 2px solid #e2e8f0;
          }
          .entries-table td {
            padding: 10px 8px;
            border-bottom: 1px solid #f1f5f9;
            font-size: 13px;
            color: #475569;
          }
          .entries-table tr:hover {
            background-color: #f8fafc;
          }
          .duration-cell {
            font-weight: 600;
            color: #059669;
            text-align: right;
          }
          .note-cell {
            max-width: 300px;
            word-wrap: break-word;
            white-space: normal;
            line-height: 1.4;
          }
          .preview-notice {
            background: #fef3c7;
            border: 1px solid #f59e0b;
            color: #92400e;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: 500;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="client-name">${e.client||"Timesheet Report"}</div>
            <div class="report-title">Professional Timesheet Report</div>
            <div class="grouping-info">${p}</div>
          </div>

          <div class="summary-section">
            <div class="summary-card">
              <h3>Total Hours</h3>
              <p class="value">${i.toFixed(2)}</p>
            </div>
            <div class="summary-card">
              <h3>Total Entries</h3>
              <p class="value">${o}</p>
            </div>
            <div class="summary-card">
              <h3>Team Members</h3>
              <p class="value">${n.length}</p>
            </div>
            <div class="summary-card">
              <h3>Projects</h3>
              <p class="value">${l.length}</p>
            </div>
          </div>

          <div class="details-section">
            <div class="detail-card">
              <h3>Team Members</h3>
              <ul class="detail-list">
                ${n.map(e=>`<li>${e}</li>`).join("")}
              </ul>
            </div>
            <div class="detail-card">
              <h3>Projects</h3>
              <ul class="detail-list">
                ${l.map(e=>`<li>${e}</li>`).join("")}
              </ul>
            </div>
          </div>

          ${c.length>0?`
            <div class="preview-notice">
              Preview showing first ${c.length} group(s) of ${t.size} total groups
            </div>
          `:""}

          <div class="entries-section">
            ${c.map(([e,t])=>{let r=t.reduce((e,t)=>e+parseFloat(t.duration||"0"),0);return`
                <div class="group-header">
                  <span>${e||"All Entries"}</span>
                  <span class="group-stats">${t.length} entries • ${r.toFixed(2)} hours</span>
                </div>
                <table class="entries-table">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>User</th>
                      <th>Client</th>
                      <th>Project</th>
                      <th>Task</th>
                      <th>Start Time</th>
                      <th>Duration</th>
                      <th>Note</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${t.map(e=>`
                      <tr>
                        <td>${e.date}</td>
                        <td>${e.user}</td>
                        <td>${e.client}</td>
                        <td>${e.project}</td>
                        <td>${e.task||"-"}</td>
                        <td>${e.time_field_1307}</td>
                        <td class="duration-cell">${e.duration}h</td>
                        <td class="note-cell" title="${(e.note||"").replace(/"/g,"&quot;")}">${e.note||"-"}</td>
                      </tr>
                    `).join("")}
                  </tbody>
                </table>
              `}).join("")}
          </div>
        </div>
      </body>
      </html>
    `},w=async()=>{if(e){d(!0);try{let t=[p,u,h].filter(e=>"none"!==e).join(","),r=await fetch("/api/generate-pdf",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({data:e,grouping:t||"date"})});if(!r.ok)throw Error("Failed to generate PDF");let a=await r.blob(),s=window.URL.createObjectURL(a),i=document.createElement("a");i.style.display="none",i.href=s,i.download=`timesheet-report-${new Date().toISOString().split("T")[0]}.pdf`,document.body.appendChild(i),i.click(),window.URL.revokeObjectURL(s),document.body.removeChild(i)}catch(e){console.error("Error generating PDF:",e),alert("Failed to generate PDF. Please try again.")}finally{d(!1)}}};return e?(0,a.jsxs)("div",{className:"min-h-screen bg-gray-50",children:[(0,a.jsx)("div",{className:"bg-white shadow-sm border-b",children:(0,a.jsx)("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:(0,a.jsxs)("div",{className:"flex justify-between items-center py-4",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("h1",{className:"text-2xl font-bold text-gray-900",children:"PDF Preview"}),(0,a.jsx)("p",{className:"text-sm text-gray-600",children:"Review your timesheet report before generating PDF"})]}),(0,a.jsxs)("div",{className:"flex space-x-4",children:[(0,a.jsx)("button",{onClick:()=>g.push("/upload"),className:"px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500",children:"Upload New File"}),(0,a.jsx)("button",{onClick:w,disabled:l,className:"px-6 py-2 text-sm font-medium text-white bg-blue-600 border border-transparent rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed",children:l?"Generating...":"Generate PDF"})]})]})})}),(0,a.jsxs)("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:[(0,a.jsxs)("div",{className:"bg-white rounded-lg shadow-sm border p-6 mb-8",children:[(0,a.jsx)("h2",{className:"text-lg font-semibold text-gray-900 mb-4",children:"Grouping Options"}),(0,a.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-4 gap-4 items-end",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"block text-sm font-medium text-gray-700 mb-2",children:"Primary Grouping"}),(0,a.jsx)("select",{value:p,onChange:e=>c(e.target.value),className:"w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",children:o.map(e=>(0,a.jsx)("option",{value:e.value,children:e.label},e.value))})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"block text-sm font-medium text-gray-700 mb-2",children:"Secondary Grouping"}),(0,a.jsx)("select",{value:u,onChange:e=>m(e.target.value),className:"w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",children:o.map(e=>(0,a.jsx)("option",{value:e.value,children:e.label},e.value))})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{className:"block text-sm font-medium text-gray-700 mb-2",children:"Tertiary Grouping"}),(0,a.jsx)("select",{value:h,onChange:e=>x(e.target.value),className:"w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500",children:o.map(e=>(0,a.jsx)("option",{value:e.value,children:e.label},e.value))})]}),(0,a.jsx)("div",{children:(0,a.jsx)("button",{onClick:()=>{e&&v(e,p,u,h)},disabled:l,className:"w-full px-4 py-2 text-sm font-medium text-white bg-green-600 border border-transparent rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed",children:l?"Loading...":"Preview"})})]}),(0,a.jsx)("div",{className:"mt-4 text-sm text-gray-600",children:(0,a.jsxs)("p",{children:[(0,a.jsx)("strong",{children:"Current grouping:"})," ",[p,u,h].filter(e=>"none"!==e).map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(" → ")||"No grouping"]})})]}),(0,a.jsxs)("div",{className:"bg-white rounded-lg shadow-sm border overflow-hidden",children:[(0,a.jsxs)("div",{className:"bg-gray-50 px-6 py-4 border-b",children:[(0,a.jsx)("h2",{className:"text-lg font-semibold text-gray-900",children:"Preview"}),(0,a.jsx)("p",{className:"text-sm text-gray-600",children:"This is how your PDF will look"})]}),(0,a.jsx)("div",{className:"p-6",children:r?(0,a.jsx)("div",{className:"border border-gray-200 rounded-lg overflow-hidden",dangerouslySetInnerHTML:{__html:r}}):(0,a.jsxs)("div",{className:"text-center py-12",children:[(0,a.jsx)("div",{className:"text-gray-400",children:(0,a.jsx)("svg",{className:"mx-auto h-12 w-12",fill:"none",viewBox:"0 0 24 24",stroke:"currentColor",children:(0,a.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"})})}),(0,a.jsx)("h3",{className:"mt-2 text-sm font-medium text-gray-900",children:"No preview available"}),(0,a.jsx)("p",{className:"mt-1 text-sm text-gray-500",children:'Click "Preview" to generate a preview of your PDF'})]})})]})]})]}):(0,a.jsx)("div",{className:"min-h-screen bg-gray-50 flex items-center justify-center",children:(0,a.jsxs)("div",{className:"text-center",children:[(0,a.jsx)("div",{className:"animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"}),(0,a.jsx)("p",{className:"mt-4 text-gray-600",children:"Loading preview..."})]})})}},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},46055:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>s});var a=r(31658);let s=async e=>[{type:"image/x-icon",sizes:"16x16",url:(0,a.fillMetadataSegment)(".",await e.params,"favicon.ico")+""}]},58014:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>d,metadata:()=>l});var a=r(37413),s=r(56389),i=r.n(s),o=r(51189),n=r.n(o);r(82704);let l={title:"XML to PDF Generator",description:"Upload XML files and generate beautiful PDF documents"};function d({children:e}){return(0,a.jsx)("html",{lang:"en",children:(0,a.jsx)("body",{className:`${i().variable} ${n().variable} antialiased`,children:e})})}},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},65234:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>a});let a=(0,r(12907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/sasitha/workspace/personal/pdf-generator-app/app/preview/page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/sasitha/workspace/personal/pdf-generator-app/app/preview/page.tsx","default")},69780:(e,t,r)=>{Promise.resolve().then(r.t.bind(r,86346,23)),Promise.resolve().then(r.t.bind(r,27924,23)),Promise.resolve().then(r.t.bind(r,35656,23)),Promise.resolve().then(r.t.bind(r,40099,23)),Promise.resolve().then(r.t.bind(r,38243,23)),Promise.resolve().then(r.t.bind(r,28827,23)),Promise.resolve().then(r.t.bind(r,62763,23)),Promise.resolve().then(r.t.bind(r,97173,23))},79551:e=>{"use strict";e.exports=require("url")},82704:()=>{},87684:(e,t,r)=>{Promise.resolve().then(r.bind(r,29116))},96918:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>o.a,__next_app__:()=>c,pages:()=>p,routeModule:()=>u,tree:()=>d});var a=r(65239),s=r(48088),i=r(88170),o=r.n(i),n=r(30893),l={};for(let e in n)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(l[e]=()=>n[e]);r.d(t,l);let d={children:["",{children:["preview",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,65234)),"/home/sasitha/workspace/personal/pdf-generator-app/app/preview/page.tsx"]}]},{metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,46055))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(r.bind(r,58014)),"/home/sasitha/workspace/personal/pdf-generator-app/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,57398,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(r.t.bind(r,89999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(r.t.bind(r,65284,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(r.bind(r,46055))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]}.children,p=["/home/sasitha/workspace/personal/pdf-generator-app/app/preview/page.tsx"],c={require:r,loadChunk:()=>Promise.resolve()},u=new a.AppPageRouteModule({definition:{kind:s.RouteKind.APP_PAGE,page:"/preview/page",pathname:"/preview",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},97764:()=>{}};var t=require("../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[447,985,658],()=>r(96918));module.exports=a})();