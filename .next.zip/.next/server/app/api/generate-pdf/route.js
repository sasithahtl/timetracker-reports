(()=>{var e={};e.id=474,e.ids=[474],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},14423:(e,t,r)=>{"use strict";r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{POST:()=>o});var i=r(32190),n=r(83636),s=e([n]);async function o(e){try{let{data:t,grouping:r="date",totalsOnly:a=!1}=await e.json();if(!t||!t.entries||!Array.isArray(t.entries))return i.NextResponse.json({error:"Invalid data format"},{status:400});let s=r.split(",").map(e=>e.trim()).filter(e=>"none"!==e),o=[...t.entries].sort((e,t)=>new Date(e.date).getTime()-new Date(t.date).getTime()),d=function(e,t){let r=new Map;return 0===t.length?r.set("All Entries",{key:"All Entries",level:0,entries:e,subGroups:new Map}):e.forEach(e=>{let a=r,i=0;t.forEach((r,n)=>{let s=function(e,t){switch(t){case"date":return e.date;case"user":return e.user;case"client":return e.client;case"project":return e.project;case"task":return e.task||"No Task";default:return""}}(e,r);a.has(s)||a.set(s,{key:s,level:i,entries:[],subGroups:new Map});let o=a.get(s);n===t.length-1&&o.entries.push(e),a=o.subGroups,i++})}),r}(o,s),p=function(e,t,r=!1){let a=l(e.entries),i=e.entries.length,n=[...new Set(e.entries.map(e=>e.user))],s=[...new Set(e.entries.map(e=>e.project))];return`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <style>
        body {
          font-family: 'Inter', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          margin: 0;
          padding: 0;
          background-color: #f8fafc;
          color: #1e293b;
          line-height: 1.6;
        }
        .container {
          max-width: 1000px;
          margin: 0 auto;
          background: white;
          padding: 40px 12px 32px 12px;
          border-radius: 16px;
          box-shadow: 0 6px 24px 0 rgba(30,64,175,0.08);
        }
        .header {
          text-align: left;
          margin-bottom: 32px;
          padding-bottom: 18px;
          border-bottom: 3px solid #3b82f6;
        }
        .client-name {
          font-size: 2rem;
          font-weight: 800;
          color: #1e40af;
          margin-bottom: 0.5rem;
          text-transform: uppercase;
          letter-spacing: 1px;
        }
        .report-title {
          font-size: 1.25rem;
          color: #334155;
          margin-bottom: 0.5rem;
          font-weight: 600;
        }
        .summary-section {
          display: flex;
          gap: 32px;
          margin-bottom: 32px;
        }
        .summary-card {
          background: linear-gradient(135deg, #3b82f6 0%, #6366f1 100%);
          color: white;
          padding: 18px 28px;
          border-radius: 12px;
          text-align: center;
          min-width: 120px;
          flex: 1;
        }
        .summary-card h3 {
          margin: 0 0 8px 0;
          font-size: 0.95rem;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          opacity: 0.9;
          font-weight: 600;
        }
        .summary-card .value {
          font-size: 1.5rem;
          font-weight: 800;
          margin: 0;
        }
        .details-section {
          display: flex;
          gap: 32px;
          margin-bottom: 32px;
        }
        .detail-card {
          background: #f1f5f9;
          padding: 18px 24px;
          border-radius: 10px;
          border-left: 4px solid #3b82f6;
          flex: 1;
        }
        .detail-card h3 {
          margin: 0 0 12px 0;
          color: #1e40af;
          font-size: 1rem;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          font-weight: 700;
        }
        .detail-list {
          list-style: none;
          padding: 0;
          margin: 0;
        }
        .detail-list li {
          padding: 4px 0;
          border-bottom: 1px solid #e2e8f0;
          color: #475569;
          font-size: 0.98rem;
        }
        .detail-list li:last-child {
          border-bottom: none;
        }
        .entries-section {
          margin-top: 32px;
        }
        .group-header {
          background: linear-gradient(90deg, #1e40af 0%, #3b82f6 100%);
          color: white;
          padding: 12px 20px;
          margin: 24px 0 0 0;
          border-radius: 10px 10px 0 0;
          font-weight: bold;
          font-size: 1.1rem;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .group-stats {
          font-size: 0.98rem;
          opacity: 0.9;
        }
        .entries-table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 24px;
          background: white;
          border-radius: 0 0 10px 10px;
          overflow: hidden;
          box-shadow: 0 2px 8px rgba(30,64,175,0.04);
        }
        .entries-table th {
          background: #f1f5f9;
          padding: 10px 6px;
          text-align: left;
          font-weight: 700;
          color: #334155;
          font-size: 0.95rem;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          border-bottom: 2px solid #e2e8f0;
        }
        .entries-table td {
          padding: 8px 6px;
          border-bottom: 1px solid #f1f5f9;
          font-size: 0.98rem;
          color: #475569;
        }
        .entries-table tr:hover {
          background-color: #f8fafc;
        }
        .duration-cell {
          font-weight: 700;
          color: #059669;
          text-align: right;
        }
        .note-cell {
          max-width: 400px;
          word-wrap: break-word;
          white-space: pre-line;
          line-height: 1.4;
        }
        .total-row {
          background: #e0e7ff;
          font-weight: 800;
          color: #1e40af;
        }
        .main-title {
          font-size: 2rem;
          font-weight: 800;
          color: #1e40af;
          margin-bottom: 0.5rem;
          letter-spacing: 1px;
        }
        .client-subheading {
          font-size: 1.25rem;
          color: #334155;
          margin-bottom: 0.5rem;
          font-weight: 600;
          text-transform: uppercase;
        }
        .totals-only .group-header {
          margin-bottom: 16px;
          border-radius: 10px;
        }
        .group-header[style*="margin-left"] {
          background: linear-gradient(90deg, #6366f1 0%, #8b5cf6 100%);
          font-size: 1rem;
          margin-top: 12px;
        }
        .group-header[style*="margin-left: 40px"] {
          background: linear-gradient(90deg, #8b5cf6 0%, #a855f7 100%);
          font-size: 0.95rem;
          margin-top: 8px;
        }
      </style>
    </head>
    <body>
      <div class="container${r?" totals-only":""}">
        <div class="header">
          <div class="main-title">Timesheet Report${r?" - Summary View":""}</div>
          <div class="client-subheading">${e.client||"No Client"}</div>
          ${r?'<div style="color: #6366f1; font-size: 0.9rem; margin-top: 8px;">This report shows group totals only. Individual entries are hidden.</div>':""}
        </div>

        <div class="summary-section">
          <div class="summary-card">
            <h3>Total Hours</h3>
            <p class="value">${a}</p>
          </div>
          <div class="summary-card">
            <h3>Total Entries</h3>
            <p class="value">${i}</p>
          </div>
          <div class="summary-card">
            <h3>Team Members</h3>
            <p class="value">${n.length}</p>
          </div>
          <div class="summary-card">
            <h3>Projects</h3>
            <p class="value">${s.length}</p>
          </div>
        </div>

        <div class="details-section">
          <div class="detail-card">
            <h3>Team Members</h3>
            <ul class="detail-list">
              ${n.map(e=>`<li>${e}</li>`).join("")}
            </ul>
          </div>
          <div class="detail-card">
            <h3>Projects</h3>
            <ul class="detail-list">
              ${s.map(e=>`<li>${e}</li>`).join("")}
            </ul>
          </div>
        </div>

        <div class="entries-section">
          ${function e(t,r,a=0){return Array.from(t.entries()).map(([t,i])=>{let n=function e(t){let r=[...t.entries];for(let a of t.subGroups.values())r=r.concat(e(a));return r}(i),s=l(n),o=a>0?`style="margin-left: ${20*a}px;"`:"",d=`
      <div class="group-header" ${o}>
        <span>${t||"All Entries"}</span>
        <span class="group-stats">${n.length} entries • ${s} hours</span>
      </div>
    `;return i.subGroups.size>0?d+=e(i.subGroups,r,a+1):i.entries.length>0&&!r&&(d+=`
        <table class="entries-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>User</th>
              <th>Client</th>
              <th>Project</th>
              <th>Task</th>
              <th>Duration</th>
              <th>Note</th>
            </tr>
          </thead>
          <tbody>
            ${i.entries.map(e=>`
              <tr>
                <td>${e.date}</td>
                <td>${e.user}</td>
                <td>${e.client}</td>
                <td>${e.project}</td>
                <td>${e.task||"-"}</td>
                <td class="duration-cell">${function(e){if(!e)return"00:00";let[t,r]=e.split(":");return`${t.padStart(2,"0")}:${(r||"00").padStart(2,"0")}`}(e.duration)}</td>
                <td class="note-cell" title="${e.note||""}">${e.note||"-"}</td>
              </tr>
            `).join("")}
            <tr class="total-row">
              <td colspan="5" style="text-align:right;">Subtotal</td>
              <td class="duration-cell">${l(i.entries)}</td>
              <td></td>
            </tr>
          </tbody>
        </table>
      `),d}).join("")}(t,r)}
        </div>
      </div>
    </body>
    </html>
  `}(t,d,a),c=await n.default.launch({headless:!0,args:["--no-sandbox","--disable-setuid-sandbox"]}),u=await c.newPage();await u.setContent(p,{waitUntil:"networkidle0"});let m=await u.pdf({format:"A4",printBackground:!0,margin:{top:"20mm",right:"15mm",bottom:"20mm",left:"15mm"}});return await c.close(),new i.NextResponse(m,{headers:{"Content-Type":"application/pdf","Content-Disposition":`attachment; filename="timesheet-report-${new Date().toISOString().split("T")[0]}.pdf"`}})}catch(e){return console.error("Error generating PDF:",e),i.NextResponse.json({error:"Failed to generate PDF"},{status:500})}}function l(e){let t=0;for(let r of e){if(!r.duration)continue;let[e,a]=r.duration.split(":");t+=60*parseInt(e||"0",10)+parseInt(a||"0",10)}let r=Math.floor(t/60),a=t%60;return`${r.toString().padStart(2,"0")}:${a.toString().padStart(2,"0")}`}n=(s.then?(await s)():s)[0],a()}catch(e){a(e)}})},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},83636:e=>{"use strict";e.exports=import("puppeteer")},96487:()=>{},96878:(e,t,r)=>{"use strict";r.a(e,async(e,a)=>{try{r.r(t),r.d(t,{patchFetch:()=>d,routeModule:()=>p,serverHooks:()=>m,workAsyncStorage:()=>c,workUnitAsyncStorage:()=>u});var i=r(96559),n=r(48088),s=r(37719),o=r(14423),l=e([o]);o=(l.then?(await l)():l)[0];let p=new i.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/generate-pdf/route",pathname:"/api/generate-pdf",filename:"route",bundlePath:"app/api/generate-pdf/route"},resolvedPagePath:"/home/sasitha/workspace/personal/pdf-generator-app/app/api/generate-pdf/route.ts",nextConfigOutput:"",userland:o}),{workAsyncStorage:c,workUnitAsyncStorage:u,serverHooks:m}=p;function d(){return(0,s.patchFetch)({workAsyncStorage:c,workUnitAsyncStorage:u})}a()}catch(e){a(e)}})}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[447,580],()=>r(96878));module.exports=a})();